apt update
apt install -y vlc